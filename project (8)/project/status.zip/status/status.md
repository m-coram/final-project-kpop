# Status Report

#### Your name

TODO

#### Your section leader's name

TODO

#### Project title

TODO

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

TODO

#### What have you not done for your project yet?

TODO

#### What problems, if any, have you encountered?

TODO
